# Ian Bateman Biography

Photo of Ian in the Media Kit folder labeled "ian_bateman_photo.jpg"

Ian Bateman is the Founder and CEO of Allieae, Inc., a software company that enables people use the internet freely and privately. Allieae's primary product, FreePN, is the first free, fast, anonymous, unlimited-bandwidth, peer-to-peer VPN. FreePN is open source software licensed under AGPLv3, and can be used by anyone, free of charge.

Ian Bateman was born on September 14, 1995 in Manasquan, New Jersey. He studied at The Hotchkiss School before attending Dartmouth College, where he received his B.A. in Computer Science and English in 2017, graduating in just three years.

### Childhood

Technology is something that has fascinated Ian Bateman since he was given his first laptop at age 7. As a naturally curious child, he spent hours learning the ins-and-outs of computer programming, building his first website at 9 years old. Along with programming, Bateman was also an avid reader. Continuing to study during his elementary school summer breaks, Bateman would eventually read over 500 books, many business books that helped spark his initial interest in startups. Particularly, Bateman was enamored with the science-fiction works of William Gibson and Orson Scott Card and the technological futures they depicted in their works.

### Startup Journey

At 23 years old, Ian Bateman sold his first startup, Orchard Systems, a company that he founded with fellow undergraduate Thomas Cecil while still a sophomore at Dartmouth College. What started off as a simple online ordering platform for his fellow classmates quickly reached over $400,000 in revenue, and Orchard Systems eventually transitioned into a sophisticated Remote Management System for brick and mortar establishments. Within 3 years of starting, Orchard Systems had raised over $2M in venture funding and grew to nearly 20 people. Orchard was successfully acquired by a large payments company in summer 2019.

Bateman has always been fascinated with the philosophy of FOSS and the potential of peer-to-peer software in general. Inspired early on by the revelations of Edward Snowden, and wanting to preserve the free-spirit of the late '90s / early 00's Internet he grew up with, Bateman jumped at the opportunity to work on making online privacy more accessible to everyone.

Currently, there are a number of 'freemium' VPNs, but virtually all of them cap bandwidth, throttle connection speed, log user data, or inject malicious ads. The only other viable options to stay private online are to either purchase a VPN subscription, use the Tor network, or spend the time and effort to run your own server. FreePN was created in response to both the lack of free, easy-to-use privacy tools online, and the major technical issues plaguing the Tor network. Taking inspiration from the high-level principles of the Tor network, FreePN is working to develop a solution that provides the same level of anonymity, while solving many of the existing issues with the Tor network, including speed, reliability, and scalability.
