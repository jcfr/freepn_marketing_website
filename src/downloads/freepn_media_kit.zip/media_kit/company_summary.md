# What is FreePN?

FreePN enables people to use the internet freely and privately. It is the first free, fast, anonymous, unlimited-bandwidth, peer-to-peer VPN. FreePN is open source software licensed under AGPLv3, and can be used by anyone, free of charge.

FreePN's founder, Ian Bateman, an Internet privacy advocate, created FreePN with the goal of making online privacy more ubiquitous and easily accessible to the average user.

Currently, there are a number of 'freemium' VPNs, but virtually all of them cap bandwidth, throttle connection speed, log user data, or inject malicious ads. The only other viable options to stay private online are to either purchase a VPN subscription, use the Tor network, or spend the time and effort to run your own server. FreePN was created in response to both the lack of free, easy-to-use privacy tools online, and the major technical issues plaguing the Tor network. Taking inspiration from the high-level principles of the Tor network, FreePN is working to develop a solution that provides the same level of anonymity, while solving many of the existing issues with the Tor network, including speed, reliability, and scalability.

FreePN is managed & run by a fully remote team.
