# FreePN FAQ

Answers to the most frequently asked questions about FreePN.

1. What is FreePN?

FreePN is the world's first and only completely free, fast, secure, anonymous, unlimited-bandwidth VPN.

FreePN works just like any other VPN - it protects your identity online by masking your IP address, preventing Internet Service Providers (ISPs), governments, and third-parties like ad-services or hackers from tracking you or monitoring your activity.

FreePN can also protect you on public Wi-Fi networks, unblock geo-restricted content, prevent bandwidth throttling by ISPs, and allow you to bypass local government censorship on specific apps and websites.

2. Why should I use FreePN?

There are many reasons you should use FreePN. You should use FreePN if you want to be secure on the Internet. You should use FreePN if you want to protect your privacy on the Internet. You should use FreePN if you want to be anonymous on the Internet. You should use FreePN if you want to access geo-blocked content, access applications or websites censored by your local government, stay safe on public Wi-Fi networks, or stop ISPs, governments, and third-parties from tracking you on the Internet.

You should use FreePN if you want to support open-source software and the future of a free and open Internet.

3. What is a VPN?

The easiest way to think about a VPN (virtual private network) is as a tunnel from your computer to another computer somewhere else on the Internet, that then allows you to browse the Internet using that computer’s connection.

A VPN is the quickest, most convenient way to protect your security, privacy, and anonymity on the Internet.

4. Why was FreePN created?

We believe that security, privacy, and anonymity on the Internet should be a fundamental right. Given this belief, an open-source, free-to-use tool to protect users online seemed like the best possible response to the challenges facing the Internet today.

FreePN is dedicated to continuing the fight for online security, privacy, and anonymity into the future. If the Internet is to remain critical infrastructure for modern life, continuing this fight is, and will remain, a necessity.

5. Why should I care about online privacy?

Have you ever noticed that after shopping for birdhouses online, you start to see a bunch of ads for birdhouses on other sites you visit? If not, try it now, then come back. This happens because you are being tracked online. Technology companies, ad services, ISPs, governments and more all monitor your behavior on the Internet.

You might be thinking ‘well, what do I care if they track me?’, or ‘I have nothing to hide - so I have nothing to fear’. The truth is though, we all have things we want to keep private. Saying you don't care about privacy because you have nothing to hide is like saying you don't care about free speech because you have nothing to say. How comfortable would you be if everyone you knew could see exactly how much money you make? How would you feel if your medical records, emails, text messages, TV watching habits, or personal documents were all publicly available for anyone to see? What would your reaction be if your search and browsing history were sent to your friends, your family, your colleagues?

If any of the preceding examples made you feel the slightest bit uncomfortable, you should care about privacy on the Internet, and support a free and open web. Privacy isn’t also just about what you do - it’s also who you are. And even if you’re not a target today, who knows what tomorrow will hold? One only need remember the words of Martin Niemöller to be reminded why fighting for what you believe in matters today.

6. What personal information does FreePN collect?

FreePN does not collect any personal information about you. There is no such thing as a FreePN account. We do not collect logs of any kind. Our goal is to protect your privacy and to help you remain anonymous on the Internet.

FreePN does prompt for an email address the first time you launch the application. This is simply so that we can send you information about critical security updates and other updates regarding our service. We never verify your email address or associate it with you in any way, and you can, in fact, enter any random email address to satisfy this dialog - such as <em>fake_email@sharklasers.com.</em> This prompt is also entirely skippable.

7. How do I know I can trust FreePN?

Unlike other VPN providers, FreePN's code is completely open-source. This means that you don't need to trust the claims FreePN makes about your security and privacy - you can verify them for yourself by checking out our source code [here](https://www.github.com/freepn).

8. Why is FreePN open-source?

At FreePN, we believe the only security you can trust is security you can see. Many companies and VPN providers make claims about protecting user privacy, not logging user behavior, using strong encryption without backdoors, and the like - but the truth is, unless your application's code is open-source, it's a black box and you don't really know what it's doing.

FreePN's code is open-source so that you can verify for yourself that we do what we say we do.

9. How does FreePN work?

In short, FreePN is functionally a peer-to-peer VPN network. The FreePN organization itself only runs a coordinating server to help make connections between peers possible. Each user on our network also functions as a VPN server themselves for someone else on the network.

FreePN uses special ['leaky-bucket algorithms'](https://en.wikipedia.org/wiki/Leaky_bucket) so that you should never notice a negative impact on your own Internet speed while using FreePN. Using FreePN is just as fast (if not faster) than using any other paid VPN service available today.

10. How can I contribute to FreePN?

Contributing to FreePN is easy. All of our source code is publicly available on GitHub [here](https://www.github.com/freepn). Feel free to tackle any open issue! If you have ideas you want to share for how to improve FreePN, feel free to reach out to us at contact@freepn.com - we read every email!

11. How can I support FreePN?

FreePN currently accepts anonymous donations of Bitcoin, Ethereum, and Litecoin.

Bitcoin address: 3ERSeY1V5gU7fNMyfiNg5XxdZRUWTu6Zy4
Ethereum address: 0x71bE78dB5c08e1303eCf0d77d8B054ca97F8F5f6
Litecoin address: MGz3TwkYkgVMTScFHgy66rTDZ7rWjN6fQb

12. Where can I download FreePN?

You can easily download FreePN [here](https://freepn.com/index.html#landing_section_two_link_anchor).

13. Which operating systems do you currently support?

We currently only support Linux-based operating systems with the following build distributions: Debian, Fedora, Gentoo, and Ubuntu. We have a .Applmage build for others.

Mac and Windows are in the works! Email us at contact@freepn.com if you'd like first access to these versions!

14. How is FreePN different or better than Tor?

Tor consists of a network of client, relays, and exit nodes. Currently, Tor implements a 'three hop' architecture in its network routing. This means that information sent from your computer must pass through three different other computers before eventually reaching its destination, and then return via the same path. This process can be extremely slow, and can add tremendous latency to online interactions. The reason that Tor operates this way is to help obfuscate your IP address, particularly in the event that the exit node you are using is compromised. As of January 2020, the entirety of the Tor network comprises only ~6,000 relay nodes and ~900 exit nodes, so it is a very real possibility that a large percentage of Tor exit nodes have been compromised.

FreePN takes an entirely different approach that attempts to solve many of the problems of the Tor network. By ensuring that every client in the network is also a server, the probability that a given exit node is compromised becomes vanishingly small. Given this, it is possible to make different architectural decisions (a 'single hop', etc.) that can help FreePN be much, much faster and lower latency than the Tor network (or even any other existing VPN service), while still maintaining anonymity and security. Eventually, FreePN hopes to offer a number of configuration options to allow users to increased security past the default setting.

15. How FreePN different or better than a normal VPN service?

Unlike a normal VPN service, FreePN is faster, lower latency, open source, and above all, entirely free!

That aside, FreePN works in a completely different way than a normal VPN service. Most VPN companies have a bunch of servers scattered in data centers all over the world that they use to route your traffic. You don't actually know what software is running on those servers, or if they're logging your traffic, or what they do with your data. Other VPN services are a black-box you simply have to trust at their word. FreePN is an open source peer-to-peer network. This means that FreePN's software is completely transparent - you don't have to trust what we say about your privacy, you can check for yourself! FreePN itself does not have any servers to route your traffic (everyone who uses FreePN also acts as a server); FreePN only has 'coordinating' servers, to help make matches between peers -- so we couldn't log your data, even if we wanted to!

16. How is FreePN different than Wireguard or OpenVPN?

Like Wireguard and OpenVPN, FreePN is also open source and works with Linux. However, unlike Wireguard and OpenVPN which require you to own, manage, and run your own VPN server (and require technical chops like commandline proficiency, Linux/UNIX knowledge, and sysadmin skills), FreePN is super-simple to download and use. All you have to do to use FreePN is download and start the program. That's it! FreePN is a peer-to-peer network, so rather than the single IP address of your dedicated server, you instantly have access to thousands of potential IPs -- ultimately making FreePN the more anonymous, private, and secure choice as well.

17. Who was FreePN made for? Who should use FreePN?

FreePN was made for everyone! FreePN was created to make online privacy accessible and easy-to-use for everyone on the Internet. The more people that use FreePN, the faster, lower latency, more secure, and more anonymous the network becomes! FreePN is the easiest way to protect yourself on the Internet. Help your parents, your friends, and your dog install FreePN and kickstart the privacy revolution today!
