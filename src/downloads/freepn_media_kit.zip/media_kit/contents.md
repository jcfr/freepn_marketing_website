What's in our Media Kit?

- Ian Bateman Biography
- Company Summary
- Photo of Ian
- Logos
- Answers to Frequently Asked Questions (FAQ)
- Contact Information for the PR Department

Future to add:

- List of Industry Awards
- Other Noteworthy News Stories About Your Brand
- Company History
- Recent Press Releases
